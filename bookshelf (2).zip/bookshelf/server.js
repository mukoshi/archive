const db = require("inflames.db").sqlite("database");
const express = require("express");
const app = express();
const path = require("path");
const bodyParser = require('body-parser');
const axios = require('axios');   
 // For database requests
const _ = require('lodash');

app.use(express.static(path.join(__dirname, 'public')));

// Middleware'ler
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
  });




app.post('/submit-form', (req, res) => {
    const { name, lname } = req.body;
  
    // Veritabanına kayıt
    db.set("students", { name, lname });
  
    res.status(201).json({ message: 'Veri başarıyla kaydedildi!' });
  });

app.get('/api/students', (req, res) => {
    const searchTerm = req.query.search; // Get search term from query parameter
  
    // Database query logic
    // Replace this with your actual database interaction using inflames.db
    const students = Array.isArray(db.get('students')) ? db.get('students') : [db.get('students') || {}];
    const filteredStudents = searchTerm ? students.filter(student => student.name && student.name.toLowerCase().includes(searchTerm.toLowerCase())) : students; // Filter based on search term (optional)
  
    res.json(filteredStudents); // Send filtered student data as JSON
  });
/* app.get('/', (req, res) => {
    res.render("index.html")
})  */

/* app.get('/:filename', (req, res) => {
    try {
        let filestring = req.params.filename.toString()
        if (checkfile(filestring)) {
            res.render(filestring)
        }
        else {
            res.render("404.html")
        }
    } catch (error) {
        console.error(error)
        res.render("500.html")
    }
});   */

let PORT = 3000
app.listen(PORT, () => {
    console.log(`Sunucu http://localhost:${PORT} üzerinde çalışıyor`);
  });

