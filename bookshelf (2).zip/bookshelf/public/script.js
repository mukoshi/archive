function yonlendir(string) {
    window.location.href = `${string}`;
}


document.getElementById("kitapverbuton").addEventListener("click", function(event) {
    kitapver(event);
  });

function kitapver(event) {
    event.preventDefault();
    /* let isim = document.getElementsByName('studentN')[0].value;
    let soyisim = document.getElementsByName('studentlN')[0].value;
    let okulnumarasi = document.getElementsByName('schoolnumber')[0].value;
    let kitapismi = document.getElementsByName('bookN')[0].value;
    let kitapkodu = document.getElementsByName('bookid')[0].value; */
    let isim = document.querySelector('[name="studentN"]').value;
    let soyisim = document.querySelector('[name="studentlN"]').value;
    let okulnumarasi = document.querySelector('[name="schoolnumber"]').value;
    let kitapismi = document.querySelector('[name="bookN"]').value;
    let kitapkodu = document.querySelector('[name="bookid"]').value;

    console.log(isim, soyisim,okulnumarasi,kitapismi,kitapkodu)

    const data = {
        name: isim,
        lname: soyisim,
        schoolnumber: okulnumarasi,
        bookname: kitapismi,
        bookid: kitapkodu,
        //... more fields as needed
    };

    fetch('/submit-form', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',  // JSON formatında veri gönder
        },
        body: JSON.stringify(data),  // Verileri JSON formatında gönder
    })
    .then(response => response.json())  // Sunucudan gelen cevabı JSON olarak al
    .then(result => {
        console.log('Success:', result);
        alert('Form başarıyla gönderildi!');  // Başarılı mesajı
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Form gönderiminde hata oluştu.');
    });
}


const input = document.getElementById('studentN');
const suggestions = document.getElementById('suggestions');

input.addEventListener('input', () => {
  const searchTerm = input.value;

  // Veritabanına istek gönderme (fetch veya axios kullanarak)
  fetch(`/api/students?search=${searchTerm}`)
    .then(response => response.json())
    .then(data => {
      suggestions.innerHTML = '';
      data.forEach(student => {
        const suggestion = document.createElement('div');
        suggestion.textContent = student.name;
        suggestion.addEventListener('click', () => {
          input.value = student.name;
          // Diğer bilgileri de doldur (örneğin, soyadı, okul numarası)
        });
        suggestions.appendChild(suggestion);
      });
    });
});