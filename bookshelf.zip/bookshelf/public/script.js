function yonlendir(string) {
  window.location.href = `${string}`;
}

document.getElementById("kayitbuton").addEventListener("click", function (event) {
  kayitbuton(event);
});

document.getElementById("searchuye").addEventListener("click", function (event) {
  searchuye(event);
});

function searchuye(event) {
  event.preventDefault();
  let isim = document.querySelector('[name="studentN"]').value;
  let okulnumarasi = document.querySelector('[name="schoolnumber"]').value;
  //console.log(okulnumarasi)
  if (isim.trim().length === 0 && okulnumarasi.trim().length === 0) { alert("Alanlar boş bırakılamaz."); return; }


  let tablo = document.getElementById("ogrencilistesi");
  tablo.style.display = "block";
  if (okulnumarasi.trim().length == 0) {
    ara(isim)
  } else if (isim.trim().length == 0) {
    ara(okulnumarasi)
  } else {
    if (ara(isim) !== ara(okulnumarasi)) { alert("Böyle bir üye yok!") }
    else { ara(okulnumarasi) }
  }
}

function kayitbuton(event) {
  event.preventDefault();
  let isim = document.querySelector('[name="studentN"]').value;
  let okulnumarasi = document.querySelector('[name="schoolnumber"]').value;

  if (isim.trim().length === 0 || okulnumarasi.trim().length === 0) {
    alert('Alanlar boş bırakılamaz.');
    return;  // Alanlar doldurulmadıysa işlem iptal ediliyor
  }
  //console.log(doesExist(okulnumarasi));

  doesExist(okulnumarasi)
    .then(exists => {
      if (exists) {
        alert("Bu numaraya sahip bir öğrenci zaten mevcut.")
        console.log("Bu numaraya sahip bir öğrenci zaten mevcut.");
      } else {
        console.log("Kayıt mevcut değil.");


        console.log(isim, okulnumarasi)

        const data = {
          name: isim,
          schoolnumber: okulnumarasi,
        };

        uyeyolla(data)

      }
    })
    .catch(error => {
      console.error("Bir hata oluştu:", error);
    });

}

function uyeyolla(data) {
  fetch('/submit-form', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',  // JSON formatında veri gönder
    },
    body: JSON.stringify(data),  // Verileri JSON formatında gönder
  })
    .then(response => response.json())  // Sunucudan gelen cevabı JSON olarak al
    .then(result => {
      console.log('Success:', result);
      alert('Form başarıyla gönderildi!');
      location.reload();  // Başarılı mesajı
    })
    .catch(error => {
      console.error('Error:', error);
      alert('Form gönderiminde hata oluştu.');
    });
}

function kitapver() {
  // Veritabanından başlangıç verilerini çekme
  fetch('/api/initial-data-books')
    .then(response => response.json())
    .then(data => {
       console.log('Initial books data:', data);
       bookspage = document.getElementById('bookspage');
       bookspage.style.display = "block";

       /* div = document.createElement('div');
       div.setAttribute("id", "bookspage");
       div.innerHTML = `<table id="ogrencilistesi">
                          <tr>
                            <th>Adı</th>
                            <th>Okul Numarası</th>
                            <th>İşlemler</th>
                          </tr>
                        </table>` */
      })
}


function isimfill(string) {
  var datalisto = document.getElementById('numaras-datas');

  var newcontent = `<option value="${string}">`
  datalisto.insertAdjacentHTML('beforeend', newcontent)
}

let array1 = ["sonertasli", "kamalamcas"]
/* isimfill(array1) */




function tableolustur(name, number) {
  var datalisto = document.getElementById('ogrencilistesi');
  var newcontent = `<tr style="display:none;" id=${number}>
                    <td>${name}</td>
                    <td>${number}</td>
                    <td><button class="buton-mini" style="background-color:cyan;" onclick="kitapver();">Kitap teslim</button>
                    <button class="buton-mini" style="background-color: cyan;" onclick="">Kitap iade</button>
                    <button class="buton-mini" style="background-color:chocolate;" onclick="">Geçmiş kayıtlar</button>
                    <button class="buton-mini" style="background-color: red;" onclick="">Üyeyi düzenle</button></td>
                    </tr>`
  datalisto.insertAdjacentHTML('beforeend', newcontent)
}
//tableolustur()



function startupdb() {
  // Veritabanından başlangıç verilerini çekme
  fetch('/api/initial-data')
    .then(response => response.json())
    .then(data => {
      console.log('Initial data:', data);
      for (let i = 0; data[0].length > i; i++) {
        tableolustur(data[0][i].name, data[0][i].schoolnumber);
      }
      //return data;
    });
}
startupdb()

let arr = [];

function ara(string) {
  var ogrencitable = document.getElementById('ogrencilistesi');


  arr.forEach(id => {
    const element = document.getElementById(id);
    if (element) {
      element.style.display = 'none';
    }
  });
  arr = []; // arr dizisini temizle


  fetch('/api/initial-data')
    .then(response => response.json())
    .then(data => {
      let newData = data[0].map(x => Object.fromEntries(Object.entries(x).map(
        ([key, value]) => [key, typeof value == 'string' ? value.toLowerCase() : value])));

      x = newData.filter(obj => Object.values(obj).some(val => val.includes(string)));
      if (!x) { alert("Böyle bir üye yok!"); return; }
      //if (x) 
      for (var i = 0; i < x.length; i++) {
        displayac(x[i].schoolnumber);
      }
      console.log(x);
    });
}

function displayac(id) {
  document.getElementById(id).style.display = '';

  arr.push(id);
}


function doesExist(id) {
  return fetch('/api/initial-data')
    .then(response => response.json())
    .then(data => {
      let newData = data[0].map(x => Object.fromEntries(Object.entries(x).map(
        ([key, value]) => [key, typeof value == 'string' ? value.toLowerCase() : value])));

      let x = newData.filter(obj => Object.values(obj).some(val => val.includes(id)));
      console.log(x);

      return x.length > 0; // true döndür
    });
}






/* const input = document.getElementById('studentN');
const studentid = document.getElementById('schoolnumber');
const suggestions = document.getElementById('suggestions');

input.addEventListener('input', () => {
  const searchTerm = input.value;

  // Veritabanına istek gönderme (fetch veya axios kullanarak)
  fetch(`/api/students?search=${searchTerm}`)
    .then(response => response.json())
    .then(data => {
      suggestions.innerHTML = '';
      data.forEach(student => {
        const suggestion = document.createElement('div');
        suggestion.textContent = student.name;
        suggestion.addEventListener('click', () => {
          input.value = student.name;
          studentid.value = student.schoolnumber;
          // Diğer bilgileri de doldur (örneğin, soyadı, okul numarası)
        });
        suggestions.appendChild(suggestion);
      });
    });
}); */